const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

mongoose.connect('mongodb://localhost:27017/agriproduct', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('MongoDB Connected'))
    .catch(err => console.error('MongoDB Connection Error:', err));

const consumerSchema = new mongoose.Schema({
    username: { type: String, unique: true, required: true },
    password: { type: String, required: true },
    name: { type: String, required: true },
    email: { type: String, required: true },
    phone: { type: String, required: true },
    address: { type: String, required: true },
    city: { type: String, required: true },
    postal: { type: String, required: true }
    // Other fields as needed
});

consumerSchema.pre('save', async function (next) {
    const user = this;
    if (!user.isModified('password')) {
        return next();
    }
    try {
        const hashedPassword = await bcrypt.hash(user.password, 10);
        user.password = hashedPassword;
        next();
    } catch (error) {
        return next(error);
    }
});

const Consumer = mongoose.model('Consumer', consumerSchema);

app.use(express.urlencoded({ extended: false }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.post('/signup', async (req, res) => {
    try {
        const { username, password, name, email, phone, address, city, postal } = req.body;

        const existingUser = await Consumer.findOne({ username });
        if (existingUser) {
            return res.status(400).json({ message: 'Username already exists', success: false });
        }

        const newUser = new Consumer({ username, password, name, email, phone, address, city, postal });
        await newUser.save();

        res.status(201).json({ message: 'User registered successfully', success: true });
    } catch (error) {
        res.status(500).json({ error: error.message, success: false });
    }
});

app.post('/login', async (req, res) => {
    try {
        const { username, password } = req.body;

        const consumer = await Consumer.findOne({ username });
        if (!consumer) {
            return res.status(401).json({ message: 'Invalid credentials', success: false });
        }

        const passwordMatch = await bcrypt.compare(password, consumer.password);
        if (passwordMatch) {
            res.status(200).json({ message: 'Login successful', success: true });
        } else {
            res.status(401).json({ message: 'Invalid credentials', success: false });
        }
    } catch (err) {
        res.status(500).json({ error: err.message, success: false });
    }
});

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
